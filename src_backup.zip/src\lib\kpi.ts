export const KPI_THRESHOLD = 35;
import { isTuesday, lastDayOfMonth, addDays } from 'date-fns';
import { KPIReport, KPISettings, DEFAULT_KPI_SETTINGS } from '../types';

export const isLastMeetingDayOfMonth = (date: Date, meetingDay: number) => {
  if (date.getDay() !== meetingDay) return false;
  const lastDay = lastDayOfMonth(date);
  return addDays(date, 7) > lastDay;
};

export const getReportingStatus = (date: Date = new Date(), settings: KPISettings = DEFAULT_KPI_SETTINGS) => {
  const schedule = settings.meetingSchedule || { dayOfWeek: 2, startHour: 8, startMinute: 30 };
  const day = date.getDay(); // 0: Sun, 1: Mon, 2: Tue, 3: Wed, 4: Thu, 5: Fri, 6: Sat
  const hour = date.getHours();
  const minute = date.getMinutes();
  const timeInMinutes = hour * 60 + minute;
  
  const isMeetingDay = day === schedule.dayOfWeek;
  const dayBeforeMeeting = schedule.dayOfWeek === 0 ? 6 : schedule.dayOfWeek - 1;
  const isDayBeforeMeeting = day === dayBeforeMeeting;

  const isLastMeeting = isLastMeetingDayOfMonth(date, schedule.dayOfWeek);
  const isLastBeforeMeeting = isDayBeforeMeeting && isLastMeetingDayOfMonth(addDays(date, 1), schedule.dayOfWeek);
  
  let isOpen = true;
  let isFullyLocked = false;
  let isPresenceOnlyMode = false;

  const meetingTimeInMinutes = schedule.startHour * 60 + schedule.startMinute;

  // Lock logic for the last week of the month
  if (isLastBeforeMeeting && hour === 23 && minute === 59) {
    // Locks at 23:59 the day before
    isFullyLocked = true;
  } else if (isLastMeeting) {
    // Current mapping for 08:30 meeting:
    // 00:00 to 09:00 (meetingTime + 30m): Locked
    // 09:00 to 09:30 (meetingTime + 30m to 60m): Presence Only
    // 09:30 to 12:00: Locked
    // > 12:00: Open again
    if (timeInMinutes < meetingTimeInMinutes + 30) {
      isFullyLocked = true;
    } else if (timeInMinutes >= meetingTimeInMinutes + 30 && timeInMinutes < meetingTimeInMinutes + 60) {
      isPresenceOnlyMode = true;
    } else if (timeInMinutes >= meetingTimeInMinutes + 60 && timeInMinutes < 12 * 60) {
      // Assumes 12:00 is a fixed re-open time (per user request to leave this part unchanged for now)
      isFullyLocked = true;
    }
  }

  const isBeforeMeeting = day !== schedule.dayOfWeek;
  
  return { isOpen, isFullyLocked, isPresenceOnlyMode, isMeetingDay, isLastTuesday: isLastMeeting, isBeforeMeeting };
};

export const calculateMonthlyScore = (userReports: KPIReport[], allReports: KPIReport[], settings: KPISettings = DEFAULT_KPI_SETTINGS) => {
  if (userReports.length === 0) return { total: 0, bonusNextMonth: 0, cashBonus: 0 };

  // Sort reports by date to identify the 5th week
  const sortedReports = [...userReports].sort((a, b) => {
    const dateA = a.date?.toDate ? a.date.toDate() : new Date(a.date);
    const dateB = b.date?.toDate ? b.date.toDate() : new Date(b.date);
    return dateA.getTime() - dateB.getTime();
  });

  const isFiveWeekMonth = sortedReports.length >= 5;
  const maxScore = isFiveWeekMonth ? 105 : 100;

  let monthlyPresence = 0;
  let monthlyInfoCount = 0;
  let monthlyFbShares = 0;
  let monthlyOppScore = 0;
  let monthlyTargetedGuests = 0;
  let monthlyNonTargetedGuests = 0;
  let monthlyNormalMeetings = 0;
  let monthlyJointHosting = 0;
  let monthlyJointTrip = 0;
  let monthlyOfficeMeeting = 0;
  let monthlyBusinessScore = 0;
  let monthlyBonus = 0;
  let monthlyPenalty = 0;
  let monthlyBonusNextMonth = 0;
  let monthlyCashBonus = 0;

  sortedReports.forEach((report, index) => {
    // Presence is always counted
    if (report.presenceStatus === 'present') monthlyPresence += settings.presence.onTime;
    if (report.presenceStatus === 'unexcused') monthlyPresence += settings.presence.absent;
    if (report.presenceStatus === 'late') monthlyPresence += settings.presence.late;
    if (report.presenceStatus === 'excused') monthlyPresence += (settings.presence.excused || 0);

    // Other indicators only for the first 4 weeks
    if (index < 4) {
      monthlyInfoCount += report.infoCount || 0;
      monthlyFbShares += report.fbShares || 0;
      
      let oppScore = 0;
      if (report.internalOppCount) oppScore += report.internalOppCount * settings.opportunity.internal;
      if (report.externalOppCount) oppScore += report.externalOppCount * settings.opportunity.external;
      if (report.oppCount && !report.internalOppCount && !report.externalOppCount) {
        oppScore += report.oppCount * 4; // legacy
      }
      monthlyOppScore += oppScore;
      
      const peerReportsInWeek = allReports.filter(r => r.userId !== report.userId && r.week === report.week);

      monthlyTargetedGuests += report.targetedGuests || 0;
      monthlyNonTargetedGuests += report.nonTargetedGuests || 0;
      
      // Cross-pollination for Meetings
      monthlyNormalMeetings += report.normalMeetings || peerReportsInWeek.filter(p => p.meetingParticipantIds?.includes(report.userId)).length;
      monthlyJointHosting += report.jointHosting || peerReportsInWeek.filter(p => p.hostingParticipantIds?.includes(report.userId)).length;
      monthlyJointTrip += report.jointTrip || peerReportsInWeek.filter(p => p.tripParticipantIds?.includes(report.userId)).length;
      monthlyOfficeMeeting += report.officeMeeting || peerReportsInWeek.filter(p => p.officeParticipantIds?.includes(report.userId)).length;

      // Weekly business score calculation
      let weeklyBusiness = 0;
      
      // GIVER LOGIC - 1. Self-reported giver revenue
      if (report.giverAmount > 0 && report.giverRecipientId) {
        const recipientReports = allReports.filter(r => r.userId === report.giverRecipientId);
        const matchingPiggy = recipientReports.find(r => 
          r.receiverGiverId === report.userId && 
          r.week === report.week &&
          r.piggyAmount > 0
        );

        if (matchingPiggy) {
          let minPiggy = 0;
          if (report.giverAmount >= settings.piggyBank.level6Revenue) minPiggy = settings.piggyBank.level6Piggy;
          else if (report.giverAmount >= settings.piggyBank.level5Revenue) minPiggy = settings.piggyBank.level5Piggy;
          else if (report.giverAmount >= settings.piggyBank.level4Revenue) minPiggy = settings.piggyBank.level4Piggy;
          else if (report.giverAmount >= settings.piggyBank.level3Revenue) minPiggy = settings.piggyBank.level3Piggy;
          else if (report.giverAmount >= settings.piggyBank.level2Revenue) minPiggy = settings.piggyBank.level2Piggy;
          else minPiggy = settings.piggyBank.level1Piggy;

          if (matchingPiggy.piggyAmount >= minPiggy) {
             if (report.giverAmount < 50000000) weeklyBusiness += settings.giverThresholds.level1Points;
             else if (report.giverAmount < 100000000) weeklyBusiness += settings.giverThresholds.level2Points;
             else if (report.giverAmount < 300000000) weeklyBusiness += settings.giverThresholds.level3Points;
             else if (report.giverAmount < 1000000000) weeklyBusiness += settings.giverThresholds.level4Points;
             else {
               weeklyBusiness += settings.giverThresholds.level5Points;
               monthlyBonusNextMonth += settings.giverThresholds.level5Bonus; // Added next month
             }
          }
        }
      }

      // GIVER LOGIC - 2. Peer-reported receiving from this user
      const peersReceivingFromU = peerReportsInWeek.filter(p => p.receiverGiverId === report.userId && p.piggyAmount > 0);
      peersReceivingFromU.forEach(p => {
         const alreadySelfReported = (report.giverAmount > 0 && report.giverRecipientId === p.userId);
         if (!alreadySelfReported) {
            let minPiggy = 0;
            if (p.receiverAmount >= settings.piggyBank.level6Revenue) minPiggy = settings.piggyBank.level6Piggy;
            else if (p.receiverAmount >= settings.piggyBank.level5Revenue) minPiggy = settings.piggyBank.level5Piggy;
            else if (p.receiverAmount >= settings.piggyBank.level4Revenue) minPiggy = settings.piggyBank.level4Piggy;
            else if (p.receiverAmount >= settings.piggyBank.level3Revenue) minPiggy = settings.piggyBank.level3Piggy;
            else if (p.receiverAmount >= settings.piggyBank.level2Revenue) minPiggy = settings.piggyBank.level2Piggy;
            else minPiggy = settings.piggyBank.level1Piggy;

            if (p.piggyAmount >= minPiggy) {
               if (p.receiverAmount < 50000000) weeklyBusiness += settings.giverThresholds.level1Points;
               else if (p.receiverAmount < 100000000) weeklyBusiness += settings.giverThresholds.level2Points;
               else if (p.receiverAmount < 300000000) weeklyBusiness += settings.giverThresholds.level3Points;
               else if (p.receiverAmount < 1000000000) weeklyBusiness += settings.giverThresholds.level4Points;
               else {
                 weeklyBusiness += settings.giverThresholds.level5Points;
                 monthlyBonusNextMonth += settings.giverThresholds.level5Bonus;
               }
            }
         }
      });

      // RECEIVER LOGIC (Piggy Bank)
      if (report.piggyAmount > 0) {
        // Internal and External now share the same logic based on the revenue amount
        let revenueBasis = 0;
        if (report.isPiggyExternal) {
          revenueBasis = report.receiverAmount; // For external, they should report their receiverAmount
        } else if (report.receiverGiverId) {
          // For internal, we use the receiverAmount they entered
          revenueBasis = report.receiverAmount;
        }

        if (revenueBasis > 0) {
          if (revenueBasis >= settings.piggyBank.level6Revenue && report.piggyAmount >= settings.piggyBank.level6Piggy) weeklyBusiness += settings.piggyBank.level6Points;
          else if (revenueBasis >= settings.piggyBank.level5Revenue && report.piggyAmount >= settings.piggyBank.level5Piggy) weeklyBusiness += settings.piggyBank.level5Points;
          else if (revenueBasis >= settings.piggyBank.level4Revenue && report.piggyAmount >= settings.piggyBank.level4Piggy) weeklyBusiness += settings.piggyBank.level4Points;
          else if (revenueBasis >= settings.piggyBank.level3Revenue && report.piggyAmount >= settings.piggyBank.level3Piggy) weeklyBusiness += settings.piggyBank.level3Points;
          else if (revenueBasis >= settings.piggyBank.level2Revenue && report.piggyAmount >= settings.piggyBank.level2Piggy) weeklyBusiness += settings.piggyBank.level2Points;
          else if (report.piggyAmount >= settings.piggyBank.level1Piggy) weeklyBusiness += settings.piggyBank.level1Points;
        } else {
          // Fallback if they didn't input revenue amount, just match piggy amount
          if (report.piggyAmount >= settings.piggyBank.level6Piggy) weeklyBusiness += settings.piggyBank.level6Points;
          else if (report.piggyAmount >= settings.piggyBank.level5Piggy) weeklyBusiness += settings.piggyBank.level5Points;
          else if (report.piggyAmount >= settings.piggyBank.level4Piggy) weeklyBusiness += settings.piggyBank.level4Points;
          else if (report.piggyAmount >= settings.piggyBank.level3Piggy) weeklyBusiness += settings.piggyBank.level3Points;
          else if (report.piggyAmount >= settings.piggyBank.level2Piggy) weeklyBusiness += settings.piggyBank.level2Points;
          else if (report.piggyAmount >= settings.piggyBank.level1Piggy) weeklyBusiness += settings.piggyBank.level1Points;
        }
      }

      monthlyBusinessScore += weeklyBusiness;
    }
    
    monthlyBonus += report.bonusPoints || 0;
    monthlyPenalty += report.penaltyPoints || 0;
  });

  // Apply Monthly Caps
  let total = 0;
  
  // Presence: Max 20 (4 weeks) or 25 (5 weeks)
  total += Math.min(isFiveWeekMonth ? (settings.presence.onTime * 5) : (settings.presence.onTime * 4), monthlyPresence); 

  // Info
  if (monthlyInfoCount >= settings.info.requiredCount || monthlyFbShares >= settings.facebook.requiredCount) total += settings.info.points;

  // Opportunities: max 5 opportunities total
  const maxOppPoints = 5 * Math.max(settings.opportunity.internal, settings.opportunity.external);
  total += Math.min(maxOppPoints, monthlyOppScore);

  // Guests: Max 10
  total += Math.min(10, (monthlyTargetedGuests * settings.guests.targeted) + (monthlyNonTargetedGuests * settings.guests.nonTargeted));

  // Meetings: Max 10
  total += Math.min(10, (monthlyNormalMeetings * settings.oneToOne.normal) + (monthlyJointHosting * settings.oneToOne.jointHosting) + (monthlyJointTrip * settings.oneToOne.jointTrip) + (monthlyOfficeMeeting * settings.oneToOne.officeMeeting));

  // Business & Charity: Max 35
  total += Math.min(35, monthlyBusinessScore);
  
  total += monthlyBonus;
  total -= monthlyPenalty;

  return {
    total: Math.min(maxScore, total),
    bonusNextMonth: monthlyBonusNextMonth,
    cashBonus: monthlyCashBonus
  };
};
